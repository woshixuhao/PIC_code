import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

filename = r'caseII.dat' # txt文件和当前脚本在同一目录下，所以不用写具体路径
pos = []
un=np.ones([500,500])
j=0
unm=0
with open(filename, 'r') as file_to_read:
    while True:
        lines = file_to_read.readline() # 整行读取数据
        for line in lines.split():
            pos.append(line)
        for i in range(len(pos)):
            un[j,i]=float(pos[i])/50
        pos=[]
        j+=1
        unm+=1
        if not lines:
            break
simulation_data=un
simulation_data=un[20:420]
print(simulation_data.shape)

filename = r'theory-II.dat' # txt文件和当前脚本在同一目录下，所以不用写具体路径
pos = []
un=np.ones([400,500])
j=0
unm=0
with open(filename, 'r') as file_to_read:
    while True:
        lines = file_to_read.readline() # 整行读取数据
        for line in lines.split():
            pos.append(line)
        for i in range(len(pos)):
            un[j,i]=float(pos[i])
        pos=[]
        j+=1
        unm+=1
        if not lines:
            break
theory_data=un


index=1
filename = fr'best_{index}.dat' # txt文件和当前脚本在同一目录下，所以不用写具体路径
pos = []
un=np.ones([400,500])
j=0
unm=0
with open(filename, 'r') as file_to_read:
    while True:
        lines = file_to_read.readline() # 整行读取数据
        for line in lines.split():
            pos.append(line)
        for i in range(len(pos)):
            un[j,i]=float(pos[i])
        pos=[]
        j+=1
        unm+=1
        if not lines:
            break
posterior_data=un

plt.figure(1)
plt.subplot(2,2,1)
plt.imshow(simulation_data,vmin=0,vmax=1)

plt.subplot(2,2,2)
plt.imshow(posterior_data,vmin=0,vmax=1)

plt.subplot(2,2,3)
plt.imshow(theory_data,vmin=0,vmax=1)
plt.show()


print(np.sqrt(np.sum((simulation_data-posterior_data)**2)/np.sum(simulation_data**2))*100)
print(np.sqrt(np.sum((simulation_data-theory_data)**2)/np.sum(simulation_data**2))*100)

plt.figure(1, figsize=(2.5, 2), dpi=300)
plt.axis('off')
plt.imshow(simulation_data, cmap='coolwarm',vmin=0,vmax=1)
#plt.colorbar()
#plt.colorbar(fraction=0.057)
plt.rcParams['font.family'] = 'Arial'
plt.rcParams['font.size'] = 8
plt.colorbar(fraction=0.036)
plt.tight_layout()
plt.savefig(f"origin.pdf", dpi=300)
plt.savefig(f"origin.tiff", dpi=300)
plt.show()

plt.figure(2, figsize=(2.5, 2), dpi=300)
plt.axis('off')
plt.imshow(posterior_data-simulation_data, cmap='coolwarm')
#plt.colorbar()
#plt.colorbar(fraction=0.057)
plt.rcParams['font.family'] = 'Arial'
plt.rcParams['font.size'] = 8
plt.colorbar(fraction=0.036)
plt.tight_layout()
plt.savefig(f"error_posterior_{index}.pdf", dpi=300)
plt.savefig(f"error_posterior_{index}.tiff", dpi=300)
plt.show()


plt.figure(3, figsize=(2.5, 2), dpi=300)
plt.axis('off')
plt.imshow(posterior_data, cmap='coolwarm',vmin=0,vmax=1)
plt.rcParams['font.family'] = 'Arial'
plt.rcParams['font.size'] = 8
plt.colorbar(fraction=0.036)
#plt.colorbar(fraction=0.045)
plt.tight_layout()
plt.savefig(f"posterior_{index}.pdf", dpi=300)
plt.savefig(f"posterior_{index}.tiff", dpi=300)
plt.show()