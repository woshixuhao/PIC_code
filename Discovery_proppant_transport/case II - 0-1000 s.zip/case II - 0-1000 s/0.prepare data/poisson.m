function [ P Ux Uy] = poisson( C, W )
%SLURRY Summary of this function goes here
%   Detailed explanation goes here
global Rhos Rhol Visc Nx Ny Lx Ly Dx Dy Clim Uin alphaf

% Rhos = 1.5e3;
% Rhol = 1e3;
% Visc = 1e-6;
Rhosl = ones(Nx,Ny).*((Rhos-Rhol)*C)/Rhol;
Viscsl = Visc./(1-C/Clim).^10;%1.82;
%Viscsl = (C>0.01).*100*Visc + Visc.*(C<=0.01);
Qin = Uin*W;
Pout = 0;
g = 9.81;


% Memory
P = zeros(Nx,Ny);
Ux = zeros(Nx+1,Ny);
Uy = zeros(Nx,Ny+1);
Y = ones(Nx,Ny);
Y = Y.*repmat((Dy/2:Dy:Ly),Nx,1);
K = ones(Nx,Ny).*W.^3/12./Viscsl;
IDX = reshape(1:Nx*Ny,Nx,Ny);

% Jacobian matrix
N = Nx*Ny;
RHS = zeros(N,1);
Kx = K(1:Nx-1,:).*K(2:Nx,:)./(0.5*(K(1:Nx-1,:)+K(2:Nx,:))).*(alphaf(1:Nx-1,:)+alphaf(2:Nx,:))*0.5;
Ky = K(:,1:Ny-1).*K(:,2:Ny)./(0.5*(K(:,1:Ny-1)+K(:,2:Ny))).*(alphaf(:,1:Ny-1)+alphaf(:,2:Ny))*0.5;

Ggrad = -0.5*(Rhosl(:,1:Ny-1)+Rhosl(:,2:Ny))*g;

idxConst = Nx*Ny;
cnt = N;
Value = zeros(N,1);
IdxX = reshape(IDX,Nx*Ny,1);
IdxY = reshape(IDX,Nx*Ny,1);
% x direction
IdxI = reshape(IDX(1:Nx-1,:),(Nx-1)*Ny,1);
IdxJ = reshape(IDX(2:Nx,:),(Nx-1)*Ny,1);
KIJ = reshape(Kx,(Nx-1)*Ny,1)*Dy/Dx;
IdxX(cnt+1:cnt+(Nx-1)*Ny) = IdxI;
IdxY(cnt+1:cnt+(Nx-1)*Ny) = IdxJ;
Value(cnt+1:cnt+(Nx-1)*Ny) = -KIJ;
Value(IdxI) = Value(IdxI) + KIJ;
cnt = cnt+(Nx-1)*Ny;
IdxX(cnt+1:cnt+(Nx-1)*Ny) = IdxJ;
IdxY(cnt+1:cnt+(Nx-1)*Ny) = IdxI;
Value(cnt+1:cnt+(Nx-1)*Ny) = -KIJ;
Value(IdxJ) = Value(IdxJ) + KIJ;
cnt = cnt+(Nx-1)*Ny;
% y direction
IdxI = reshape(IDX(:,1:Ny-1),Nx*(Ny-1),1);
IdxJ = reshape(IDX(:,2:Ny),Nx*(Ny-1),1);
KIJ = reshape(Ky,Nx*(Ny-1),1)*Dx/Dy;
GIJ = reshape(Ggrad,Nx*(Ny-1),1);
IdxX(cnt+1:cnt+(Ny-1)*Nx) = IdxI;
IdxY(cnt+1:cnt+(Ny-1)*Nx) = IdxJ;
Value(cnt+1:cnt+(Ny-1)*Nx) = -KIJ;
Value(IdxI) = Value(IdxI) + KIJ;
cnt = cnt+(Ny-1)*Nx;
IdxX(cnt+1:cnt+(Ny-1)*Nx) = IdxJ;
IdxY(cnt+1:cnt+(Ny-1)*Nx) = IdxI;
Value(cnt+1:cnt+(Ny-1)*Nx) = -KIJ;
Value(IdxJ) = Value(IdxJ) + KIJ;
cnt = cnt+(Ny-1)*Nx;

RHS(IdxI) = RHS(IdxI)-GIJ.*KIJ*Dy;
RHS(IdxJ) = RHS(IdxJ)+GIJ.*KIJ*Dy;

idx_tmp = Nx*Ny;
RHS(idx_tmp) = Pout;%-g*Rhosl(idx_tmp).*Y(idx_tmp);
Value = Value-Value.*(IdxX==idx_tmp);
Value = Value+(IdxX==idx_tmp).*(IdxY==idx_tmp);

%RHS(1:Nx) = RHS(1:Nx)-Ky(:,1).*Dy.*(1.5*Rhosl(:,1)-0.5*Rhosl(:,2))*g;
%RHS((Ny-1)*Nx+1:Ny*Nx) = RHS((Ny-1)*Nx+1:Ny*Nx) + Ky(:,Ny-1).*Dy.*(1.5*Rhosl(:,Ny)-0.5*Rhosl(:,Ny-1))*g;

SPS = sparse(IdxX,IdxY,Value);
%Jacob = full(sparse(IdxX,IdxY,Value));
% % Boundary condition
% % Left
% %idx_tmp = reshape(IDX(1,1:floor(Ny/2)),floor(Ny/2),1);
% idx_tmp = reshape(IDX(1,:),Ny,1);
% RHS(idx_tmp) = RHS(idx_tmp) + Qin*Dy;%.*(C(1,:)<Clim-0.1)';
% % Right
% idx_tmp = reshape(IDX(Nx,:),Ny,1);
% for i=1:Ny
%     Jacob(Nx*i,Nx*i) = Jacob(Nx*i,Nx*i)+Jacob(Nx*i,Nx*i-1);
%     Jacob(Nx*i,Nx*i-1) = Jacob(Nx*i,Nx*i-1)-Jacob(Nx*i,Nx*i-1);
% end
% idx_tmp = Nx*Ny;
% RHS(idx_tmp) = Pout;%-g*Rhosl(idx_tmp).*Y(idx_tmp);
% Jacob(idx_tmp,:) = 0;
% Jacob(idx_tmp,idx_tmp) = diag(ones(length(idx_tmp),1));

%x = Jacob\RHS;
tol = 1e-8;
maxit = 50;
%JacobSparse = sparse(Jacob);
x = agmg(SPS,RHS);
%x = gmres(sparse(Jacob),RHS,50,tol,maxit);
%x = Jacob\RHS;
P = reshape(x(:,1),Nx,Ny);
%surf(P);

G(:,Ny) = 0.5*Dy*Rhosl(:,Ny)*g; 
for i=Ny-1:-1:1
   G(:,i) = G(:,i+1) + 0.5*Dy*(Rhosl(:,i)+Rhosl(:,i+1))*g;
end
G = 0;
Psi = P+G;
Ux(2:Nx,:) = (Psi(1:Nx-1,:)-Psi(2:Nx,:))/Dx.*Kx./((alphaf(1:Nx-1,:)+alphaf(2:Nx,:))*0.5);
Ux(1,:) = Qin; % Left boundary
Ux(Nx+1,:) = Ux(Nx,:); % Right boundary
Uy(:,2:Ny) = ((Psi(:,1:Ny-1)-Psi(:,2:Ny))/Dy - 0.5*(Rhosl(:,1:Ny-1)+Rhosl(:,2:Ny))*g).*Ky./((alphaf(:,1:Ny-1)+alphaf(:,2:Ny))*0.5);

Uy(:,1) = 0;
Uy(:,Ny+1) = 0;
Ux = Ux./W;
Uy = Uy./W;
end

