import numpy as np
import random
import heapq

max_iter=5
partial_prob=0.5
genes_prob=0.7
cross_rate=0.8
mutate_rate=0.2
pop_size=200
n_generations=100

def random_module():
    genes_module=[]
    for i in range(max_iter):
        a=random.randint(0,3)
        genes_module.append(a)
        prob=random.uniform(0,1)
        if prob>partial_prob:
            break
    return genes_module

def random_gene():
    genes=[]
    for i in range(max_iter):
        gene_random=random_module()
        if sorted(gene_random) not in genes:
            genes.append(sorted(gene_random))
        prob=random.uniform(0,1)
        if prob>genes_prob:
            break
    return genes


def translate_DNA(gene,u,u_x,u_xx,u_xxx):
    gene_translate=np.ones([u.shape[0],u.shape[1]])
    for gene_module in gene:
        module_out=np.ones([u.shape[0],u.shape[1]])
        for i in gene_module:
            if i==0:
                temp=u
            if i==1:
                temp=u_x
            if i==2:
                temp=u_xx
            if i==3:
                temp=u_xxx
            module_out*=temp
        gene_translate=np.hstack((gene_translate,module_out))
    gene_translate=np.delete(gene_translate,[0],axis=1)
    return gene_translate

def get_fitness(gene_translate,u_t,u_tt,gene_t):
    # one=np.ones([gene_translate.shape[0],1])
    # gene_translate=np.hstack((gene_translate,one))
    if gene_t==1:
        lst=np.linalg.lstsq(gene_translate,u_t,rcond=None)
        coef=lst[0]
        res=u_t
        for i in range(coef.shape[0]):
            res=res-coef[i,0]*(gene_translate[:,i].reshape(u_t.shape[0],1))
        MSE=np.sum(np.abs(res)) / total+0.0005*coef.shape[0]#np.sum(res**2)/total
    if gene_t==2:
        lst = np.linalg.lstsq(gene_translate, u_tt, rcond=None)
        coef = lst[0]
        res = u_tt
        for i in range(coef.shape[0]):
            res = res - coef[i, 0] * (gene_translate[:, i].reshape(u_tt.shape[0], 1))
        MSE = np.sum(np.abs(res)) / total+0.0005* coef.shape[0]#np.sum(res ** 2)/total
    MSE_TRUE = np.sum(np.abs(res)) / total
    return coef,MSE,MSE_TRUE



def cross_over(gene,father):
    cross_prob=random.uniform(0,1)
    child=father.copy()
    total_gene=gene.copy()
    if cross_prob<cross_rate:
        mother_index=random.randint(0,len(gene)-1)
        mother=total_gene[mother_index]
        swap_index_mother = random.randint(0, len(mother)-1)
        swap_index_father= random.randint(0, len(father)-1)
        swap_mother=mother[swap_index_mother]
        child[swap_index_father]=swap_mother
    return child


def mutate_left(gene_left):
    new_left=gene_left.copy()
    for i in range(len(gene_left)):
        mutate_prob = random.uniform(0, 1)
        new_i=gene_left[i]
        if mutate_prob < mutate_rate:
            if gene_left[i]==1:
                new_i=2
            if gene_left[i]==2:
                new_i=1
        new_left[i]=new_i
    return new_left

def mutate(total_child):
    new_child=total_child.copy()
    for i in range(len(total_child)):
        mutate_prob = random.uniform(0, 1)
        child=total_child[i].copy()
        if mutate_prob < mutate_rate:
            child_index=random.randint(0,len(child)-1)
            mutate_select=child[child_index]
            gene_index=random.randint(0,len(mutate_select)-1)
            gene_select=mutate_select[gene_index]
            if gene_select==3:
                new_gene=2
            if gene_select==2:
                new_gene=1
            if gene_select == 1:
                new_gene = 0
            if gene_select == 0:
                new_gene = 3
            child[child_index][gene_index]=new_gene
            new_child[i]=child
        child_dele=new_child[i].copy()
        if len(child_dele) > 1:
            dele_prob = random.uniform(0, 1)
            if dele_prob<mutate_rate:
                delete_index = random.randint(0, len(child_dele) - 1)
                child_dele.pop(delete_index)
                new_child[i]=child_dele
        child_add=new_child[i].copy()
        add_prob = random.uniform(0, 1)
        if add_prob<mutate_rate:
            add_gene=random_module()
            new_child[i].append(add_gene)

    return new_child

def select(total_child,total_left):    # nature selection wrt pop's fitness
    fitness_list=[]
    new_left=[]
    new_child=[]
    num=0
    for child in total_child:
        child_translate=translate_DNA(child,u,u_x,u_xx,u_xxx)
        coef, MSE,MSE_TRUE = get_fitness(child_translate, u_t,u_tt,total_left[num])
        fitness_list.append(MSE)
        num+=1
    #print(fitness_list)
    re1 = list(map(fitness_list.index, heapq.nsmallest(pop_size, fitness_list)))
    #print(re1)
    re2 = heapq.nsmallest(pop_size, fitness_list)
    for index in re1:
        new_child.append(total_child[index])
        new_left.append(total_left[index])
    #print(new_child)
    return new_child,new_left


total=90000
u=np.load("U/U-quan.npy").reshape(total,1)
u_x=np.load("U/Hx_n-quan.npy").reshape(total,1)
u_xx=np.load("U/Hxx_n-quan.npy").reshape(total,1)
u_xxx=np.load("U/Hxxx_n-quan.npy").reshape(total,1)
u_t=np.load('F/F-quan.npy').reshape(total,1)
u_tt=np.load('F/F-quan.npy').reshape(total,1)

min_val = 0.05
max_val = 0.95

num = 0
for i in range(total):
    if min_val<u[i]<max_val:
        num+=1

total_new=num #120000
u_new=np.zeros([total_new,1])
ux_new=np.zeros([total_new,1])
uxx_new=np.zeros([total_new,1])
uxxx_new=np.zeros([total_new,1])
ut_new=np.zeros([total_new,1])
utt_new=np.zeros([total_new,1])
num = 0
for i in range(total):
    if min_val<u[i]<max_val:
        u_new[num]=u[i]
        ux_new[num] = u_x[i]
        uxx_new[num] = u_xx[i]
        uxxx_new[num] = u_xxx[i]
        ut_new[num] = u_t[i]
        utt_new[num] = u_tt[i]
        num+=1

total=total_new
u=u_new
u_x=ux_new
u_xx=uxx_new
u_xxx=uxxx_new
u_t=ut_new.copy()
u_tt=utt_new

#

gene_translate=translate_DNA([[0, 1],[0,0,1],[0,0,0,1],[0,0,0,0,1]],u,u_x,u_xx,u_xxx)
coef,MSE,MSE_TRUE=get_fitness(gene_translate,u_t,u_tt,1)
print(coef,MSE,MSE_TRUE)

total_MSE=[]
total_genes=[]
gene_left=[]
for i in range(pop_size):
    gene=random_gene()
    a = random.randint(1, 2)
    gene_translate=translate_DNA(gene,u,u_x,u_xx,u_xxx)
    coef,MSE,MSE_TRUE=get_fitness(gene_translate,u_t,u_tt,a)
    gene_left.append(a)
    total_genes.append(gene)
    total_MSE.append(MSE)


total_child=[]
for father in total_genes:
    child=cross_over(total_genes,father)
    total_child.append(child)
for father in total_genes:
    child=cross_over(total_genes,father)
    total_child.append(child)

new=gene_left.copy()
for left in gene_left:
    new.append(left)
gene_left=new


mutate(total_child)
gene_left=mutate_left(gene_left)
#print(total_child)
total_child_de=[]
for child in total_child:
    new_child=[]
    for item in child:
        if sorted(item) not in new_child:
            new_child.append(sorted(item))
    total_child_de.append(new_child)


child_select,left_select=select(total_child_de,gene_left)

for iter in range(n_generations):
    total_child = []
    best=child_select[0].copy()
    best_left=left_select[0]
    best_save=np.array(best)
    best_left_save=np.array(best_left)
    np.save("best_save",best_save)
    np.save("best_left_save",best_left_save)

    child_loser=child_select.copy()
    left_loser=left_select.copy()
    child_loser.pop(0)
    left_loser.pop(0)
    for father in child_loser:
        child = cross_over(child_loser, father)
        total_child.append(child)
    for father in child_loser:
        child = cross_over(child_loser, father)
        total_child.append(child)

    new = left_loser.copy()
    for left in left_loser:
        new.append(left)
    left_loser = new
    mutate(total_child)
    left_loser=mutate_left(left_loser)
    best_load=np.load("best_save.npy",allow_pickle=True)
    best_left_load=np.load("best_left_save.npy",allow_pickle=True)
    best=best_load.tolist()
    best_left=best_left_load.tolist()
    total_child.insert(0,best)
    left_loser.insert(0,best_left)
    total_child_de = []
    for child in total_child:
        new_child = []
        for item in child:
            if sorted(item) not in new_child:
                new_child.append(sorted(item))
        total_child_de.append(new_child)
    child_select,left_select = select(total_child_de,left_loser)
    print("-----------------------------")
    print("The best one: ",child_select[0])
    gene=child_select[0]
    gene_translate=translate_DNA(gene,u,u_x,u_xx,u_xxx)
    coef, MSE, MSE_true = get_fitness(gene_translate, u_t, u_tt, left_select[0])
    print("The best coef: ", coef)
    print('The best MSE', MSE)
    print('The best MSE_True', MSE_true)
    print("left is:    ", left_select[0])
