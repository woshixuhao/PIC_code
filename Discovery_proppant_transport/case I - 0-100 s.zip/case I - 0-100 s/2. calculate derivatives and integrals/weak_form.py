# -*- coding: utf-8 -*-
"""
Created on Thu Aug 20 10:43:52 2020

@author: Xu Hao
"""

import numpy as np
import torch
import random
from torch.nn import Linear, Tanh, Sequential
from torch.autograd import Variable
import torch.nn as nn
import os
import torch.nn.functional as F
from neural_network import ANN, PINNLossFunc, random_data,ANN_sin
import matplotlib.pyplot as plt

try:
    os.makedirs('F/')
    os.makedirs('U/')
except OSError:
    pass

def fun(Gauss_x,t):
    database=torch.zeros([5,2])
    for i in range(5):
        database[i,0]=Gauss_x[i]
        database[i,1]=t
    database = Variable(database, requires_grad=True)
    PINNstatic=Net(database)
    H_grad = torch.autograd.grad(outputs=PINNstatic.sum(), inputs=database, create_graph=True)[0]
    Ht = H_grad[:, 1]
    Ht_n = Ht.data.numpy()
    Htt = torch.autograd.grad(outputs=Ht.sum(), inputs=database, create_graph=True)[0][:, 1]
    Htt_n = Htt.data.numpy()
    #print(Hx)

    return Ht_n

def gauss_legenre(a,b,t):
    GauFive={0.9061798459:0.2369268851,0.5384693101:0.4786286705,0:0.5688888889}
    GauSum = 0.0
    Gauss_x=np.zeros([5])
    Gauss_x[0]=((b - a) *0.9061798459 + a + b) / 2
    Gauss_x[1]=((b - a) *0.5384693101 + a + b) / 2
    Gauss_x[2]=((b - a) *0 + a + b) / 2
    Gauss_x[3]=((a-b) *0.9061798459 + a + b) / 2
    Gauss_x[4]=((a - b) * 0.5384693101 + a + b) / 2
    Fun=fun(Gauss_x,t)
    GauSum+=Fun[0]*0.2369268851
    GauSum+=Fun[1]*0.4786286705
    GauSum+=Fun[2]*0.5688888889
    GauSum+=Fun[3]*0.2369268851
    GauSum+=Fun[4]*0.4786286705
    GauSum = GauSum * (b - a) / 2
    return GauSum

if torch.cuda.is_available():
    DEVICE = torch.device('cuda')
    torch.backends.cudnn.benchmark = True
else:
    DEVICE = torch.device('cpu')

seed_n = 525
max_tol = 10
min_tol = 0.001
iter_num = 10000000
choose_PINN = 100000
validate_PINN = 10000
noise_level = 0
Net = ANN(in_neuron=2, hidden_neuron=50, out_neuron=1)
Net.load_state_dict(torch.load('./draft-10000-99000.pkl'))
x_shape=nx=300
t_shape=nt=300
total=x_shape*t_shape
# x = np.linspace(0, 20, x_shape)
# t = np.linspace(500, 1490, t_shape)
xcoeff = 0.02
tcoeff = 1.22625e-1 # for case I
#tcoeff = 3.310149e-3# for case II
x = np.linspace(20*xcoeff, 480*xcoeff, x_shape)
t = np.linspace(4*tcoeff, 96*tcoeff, t_shape)
dx=x[1]-x[0]
length=dx
data=torch.zeros(2)
h_data=torch.zeros([total,1])
database=torch.zeros([total,2])
num=0
for j in range(nx):
    for i in range(nt):
        data[0]=x[j]
        data[1]=t[i]
        database[num]=data
        num+=1

database = Variable(database, requires_grad=True)
PINNstatic=Net(database).reshape(total,1)
H_grad = torch.autograd.grad(outputs=PINNstatic.sum(), inputs=database, create_graph=True)[0]
Hx=H_grad[:,0].reshape(total,1)
Hx_n=Hx.data.numpy().reshape(nx,nt).T
Hxx=torch.autograd.grad(outputs=Hx.sum(), inputs=database,create_graph=True)[0][:,0].reshape(total,1)
Hxx_n=Hxx.data.numpy().reshape(nx,nt).T
Hxxx=torch.autograd.grad(outputs=Hxx.sum(), inputs=database,create_graph=True)[0][:,0].reshape(total,1)
Hxxx_n=Hxxx.data.numpy().reshape(nx,nt).T
H_n=PINNstatic.data.numpy().reshape(nx,nt).T
Ht=H_grad[:,1].reshape(total,1)
Ht_n=Ht.data.numpy().reshape(nx,nt).T
np.savetxt("h.txt",H_n.T,delimiter=' ')

Inter_H_t=np.zeros([t_shape,x_shape])
F=np.zeros([t_shape,x_shape])
F[:,0]=0
for i in range(t_shape):
    for j in range(x_shape-1):
        Inter_H_t[i,j]=gauss_legenre(x[j],x[j]+length,t[i])
        if j==0:
            F[i,j+1]=Inter_H_t[i,j]
        if j!=0:
            F[i,j+1]=F[i,j]+Inter_H_t[i,j]
    print(i)



np.save('F/F-quan',F)
np.save("U/U-quan",H_n)
np.save("U/Hx_n-quan",Hx_n)
np.save("U/Hxx_n-quan",Hxx_n)
np.save("U/Hxxx_n-quan",Hxxx_n)

np.savetxt("flux.txt",F.T,delimiter=' ')
np.savetxt("hgrad.txt",Hx_n.T,delimiter=' ')
np.savetxt("ht.txt",Ht_n.T,delimiter=' ')