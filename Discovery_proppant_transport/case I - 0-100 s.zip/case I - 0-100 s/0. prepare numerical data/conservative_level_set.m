function [Cout] = conservative_level_set(C,alphaf)
% 2005, A conservative level set method for two phase flow, JCP
global Dx Dy Nx Ny lap
maxC = max(max(C));
C = C/maxC;

d = 0.1;
tau = 0.1*Dx^(1+d)/2*1;
epsilon = 1.2*Dx^(1-d)/2;
coeff = 0.25;

idxI = lap+1:lap+Nx;
idxJ = lap+1:lap+Ny;
Cgradx = (C(idxI+1,idxJ)-C(idxI-1,idxJ))/(2*Dx);
Cgrady = (C(idxI,idxJ+1)-C(idxI,idxJ-1))/(2*Dy);
CgradMag = sqrt(Cgradx.^2+Cgrady.^2);
Cnormx = Cgradx./max(1d-10,CgradMag);
Cnormy = Cgrady./max(1d-10,CgradMag);

F = zeros(Nx+1,Ny); G = zeros(Nx,Ny+1);

Cnew = C;
for i = 1:1

f = C(idxI,idxJ).*(1-C(idxI,idxJ)).*Cnormx;
g = C(idxI,idxJ).*(1-C(idxI,idxJ)).*Cnormy;
CX = 0.5*(C(lap+2:lap+Nx,idxJ)+C(lap+1:lap+Nx-1,idxJ));
CY = 0.5*(C(idxI,lap+2:lap+Ny)+C(idxI,lap+1:lap+Ny-1));
%CX = 0; CY = 0;
%alphafX = 0.5*(alphaf(1:Nx-1,:)+alphaf(2:Nx,:));
%alphafY = 0.5*(alphaf(:,1:Ny-1)+alphaf(:,2:Ny));

F(2:Nx,:) = 0.5*(f(1:Nx-1,:)+f(2:Nx,:)) - (4*CX.^10+1).*epsilon.*(C(lap+2:lap+Nx,idxJ)-C(lap+1:lap+Nx-1,idxJ))/Dx;
G(:,2:Ny) = 0.5*(g(:,1:Ny-1)+g(:,2:Ny)) - (4*CY.^10+1).*epsilon.*(C(idxI,lap+2:lap+Ny)-C(idxI,lap+1:lap+Ny-1))/Dy;
%F(2:Nx,:) = F(2:Nx,:).*alphafX;
%G(:,2:Ny) = G(:,2:Ny).*alphafY;

Cnew = C(idxI,idxJ) - tau*((F(2:Nx+1,:)-F(1:Nx,:))/Dx+(G(:,2:Ny+1)-G(:,1:Ny))/Dy)./alphaf;
C(idxI,idxJ) = Cnew;
end
%surf(Cnew);shading interp;
C(idxI,idxJ) = Cnew;
Cout = C*maxC;
end

